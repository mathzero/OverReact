### GGplot theme for REACT plots

# Created by Matt Whitaker 23/11/2021
# devtools::document()
# devtools::check()

#' @import dplyr
#' @import ggplot2
#' @import extrafont
#' @import hrbrthemes
#' @import showtext
#' @import sysfonts


theme_react <- function(base_family = "sans",
                        base_size = 11,
                        strip_text_size = 9,
                        strip_text_margin = 5,
                        subtitle_size = 12,
                        subtitle_margin = 7,
                        plot_title_size = 14,
                        plot_title_margin = 7,
                        ...){

#
#   # check if selected font is in loaded fonts
#   if(!base_family %in% as.data.frame(sysfonts::font_files())$family){
#     print(paste0(base_family," is not loaded as a system font. Replacing with sans for now"))
#     base_family <- "sans"
#     semibold_family=base_family
#   }else{
#     semibold_family="IBM Plex Sans SemiBold"
#   }


  ggplot2::`%+replace%`(
    ggplot2::theme_bw(base_size = 10, base_family = base_family,
                      base_line_size = 0.2,
                      base_rect_size = 0.1),
    ggplot2::theme(
      panel.background = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = "white", colour = NA),
      legend.background = ggplot2::element_rect(fill = "transparent", colour = NA),
      legend.key = ggplot2::element_rect(fill = "transparent", colour = NA),
      strip.background = ggplot2::element_rect(fill = "white", linewidth = 0.2),
      axis.text = ggplot2::element_text(size = 8),
      strip.text = ggplot2::element_text(face = "bold",size = strip_text_size,margin = ggplot2::margin(rep(2,4)),
                                family=base_family),

      # # from Silge
      # strip.text = ggplot2::element_text(hjust = 0, size=strip_text_size,
      #                                         margin=margin(b=strip_text_margin),
      #                                         family="IBM Plex Sans Medium"),
      plot.subtitle = ggplot2::element_text(hjust = 0, size=subtitle_size,
                                            margin=ggplot2::margin(b=subtitle_margin),
                                            family=base_family),
      plot.title = ggplot2::element_text(hjust = 0, size = plot_title_size,face = "bold",
                                         margin=ggplot2::margin(b=plot_title_margin),
                                         family=base_family)
    )
  )

}


theme_mw <- function(base_family = "sans",
                        base_size = 11,
                        strip_text_size = 9,
                        strip_text_margin = 5,
                        subtitle_size = 12,
                        subtitle_margin = 7,
                        plot_title_size = 14,
                        plot_title_margin = 7,
                     panel.grid.major = ggplot2::element_blank(),
                     panel.grid.minor =  ggplot2::element_blank(),
                     legend.position=c(1, 1),
                     legend.justification = c(1, 1),
                     legend.title = ggplot2::element_text(face = "bold"),
                        ...){


  ggplot2::`%+replace%`(
    ggplot2::theme_bw(base_size = 10, base_family = base_family,
                      base_line_size = 0.2,
                      base_rect_size = 0.1),
    ggplot2::theme(
      panel.border = ggplot2::element_rect(colour = "black", fill=NA, linewidth=0.3),
      axis.ticks = ggplot2::element_line(colour = "black",linewidth=0.3),
      legend.background = ggplot2::element_blank(),
      panel.background = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = "white", colour = NA),
      legend.key = ggplot2::element_rect(fill = "transparent", colour = NA),
      strip.background = ggplot2::element_rect(fill = "white", linewidth = 0.2),
      axis.text = ggplot2::element_text(size = 8),
      strip.text = ggplot2::element_text(face = "bold",size = strip_text_size,margin = ggplot2::margin(rep(2,4)),
                                family=base_family),

      panel.grid.major = panel.grid.major,
      panel.grid.minor =  panel.grid.minor,


      # legend
      legend.box.background = ggplot2::element_rect(colour = "black",linewidth=0.1),
      legend.position =legend.position,
      legend.justification = legend.justification,
      legend.title=legend.title,

     # subtitle and title settings
      plot.subtitle = ggplot2::element_text(hjust = 0, size=subtitle_size,
                                            margin=ggplot2::margin(b=subtitle_margin),
                                            family=base_family, face="plain"),
      plot.title = ggplot2::element_text(hjust = 0, size = plot_title_size,
                                         margin=ggplot2::margin(b=plot_title_margin),
                                         family=base_family,face="bold")
    )
  )

}
